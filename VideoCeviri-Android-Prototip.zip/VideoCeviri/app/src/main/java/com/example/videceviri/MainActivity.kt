package com.example.videceviri

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(0xFF111827.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Video Çeviri"
            textSize = 28f; setTextColor(0xFFFFFFFF.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Tarayıcıda videoyu hoparlörden oynat. Çeviriyi başlatınca konuşmalar dinlenip Türkçe altyazı olarak ekranın üzerinde gösterilir."
            textSize = 16f; setTextColor(0xFFD1D5DB.toInt()); setPadding(0, 18, 0, 24)
        })
        endpoint = EditText(this).apply {
            hint = "wss://sunucu-adresin/ws"
            setText("wss://YOUR-SERVER.example/ws")
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9CA3AF.toInt())
            setSingleLine(true)
        }
        root.addView(endpoint)
        root.addView(Button(this).apply {
            text = "ÇEVİRİYİ BAŞLAT"
            setOnClickListener { beginCapture() }
        }, LinearLayout.LayoutParams(-1, 58).apply { topMargin = 22 })
        root.addView(Button(this).apply {
            text = "DURDUR"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) }
        }, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        root.addView(TextView(this).apply {
            text = "Not: Bu ilk prototip mikrofonla dinler. En iyi sonuç için videoyu telefon hoparlöründen oynat ve sesi yeterince açık tut. Kulaklıkla veya bazı korumalı oynatıcılarda çalışmayabilir."
            textSize = 13f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0, 26, 0, 0)
        })
        setContentView(root)
    }

    private fun beginCapture() {
        if (endpoint.text.isNullOrBlank() || endpoint.text.toString().contains("YOUR-SERVER")) {
            Toast.makeText(this, "Önce sunucu adresi girilmeli.", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Altyazı penceresi iznini verip tekrar başlat.", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41); return
        }
        val i = Intent(this, CaptureService::class.java).putExtra("endpoint", endpoint.text.toString().trim())
        ContextCompat.startForegroundService(this, i)
        Toast.makeText(this, "Canlı çeviri başlatıldı.", Toast.LENGTH_SHORT).show()
    }
}
