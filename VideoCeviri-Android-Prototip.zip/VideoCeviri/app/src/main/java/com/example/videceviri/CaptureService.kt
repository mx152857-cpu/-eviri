package com.example.videceviri

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import okhttp3.*
import okio.ByteString
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class CaptureService : Service() {
    private var recorder: AudioRecord? = null
    private var socket: WebSocket? = null
    private var overlay: TextView? = null
    private var running = false
    private lateinit var wm: WindowManager
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val n = Notification.Builder(this, "capture")
            .setContentTitle("Video Çeviri çalışıyor")
            .setContentText("Canlı altyazı dinleniyor")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(7, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val url = intent?.getStringExtra("endpoint") ?: return START_NOT_STICKY
        if (!running) connect(url)
        return START_STICKY
    }

    private fun showOverlay() {
        overlay = TextView(this).apply {
            text = "Türkçe altyazı burada görünecek"
            textSize = 19f; setTextColor(Color.WHITE); setBackgroundColor(0xCC111111.toInt())
            setPadding(22, 14, 22, 14); gravity = Gravity.CENTER
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 110 }
        try { wm.addView(overlay, params) } catch (_: Exception) {}
    }

    private fun connect(url: String) {
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                running = true
                startMic(webSocket)
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val j = JSONObject(text)
                    if (j.optString("type") == "subtitle") {
                        val translated = j.optString("text")
                        overlay?.post { overlay?.text = translated }
                    } else if (j.optString("type") == "status") {
                        overlay?.post { overlay?.text = j.optString("text") }
                    }
                } catch (_: Exception) {}
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                overlay?.post { overlay?.text = "Bağlantı hatası: ${t.localizedMessage ?: "sunucuya ulaşılamıyor"}" }
                stopSelf()
            }
        })
    }

    private fun startMic(ws: WebSocket) {
        val sampleRate = 24000
        val min = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { overlay?.text = "Mikrofon başlatılamadı"; stopSelf(); return }
        recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192))
        if (recorder?.state != AudioRecord.STATE_INITIALIZED) { stopSelf(); return }
        recorder?.startRecording()
        running = true
        thread(name = "VideoCeviriMic") {
            val buffer = ByteArray(4800)
            while (running) {
                val count = recorder?.read(buffer, 0, buffer.size) ?: -1
                if (count > 0) ws.send(ByteString.of(*buffer.copyOf(count)))
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("capture", "Video Çeviri", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        socket?.close(1000, "stopped"); socket = null
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
