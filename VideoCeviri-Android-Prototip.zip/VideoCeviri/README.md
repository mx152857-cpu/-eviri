# Video Çeviri — Android prototipi

Bu klasör Android Studio ile açılabilen bir başlangıç projesi ve OpenAI Realtime Transcription kullanan küçük bir Node.js WebSocket sunucusu içerir.

## Mevcut prototipin kapsamı
- Android'de kayan altyazı penceresi (diğer uygulamaların üzerinde).
- Mikrofon üzerinden 24 kHz PCM ses yakalama.
- Sunucuya WebSocket ile ses gönderme.
- OpenAI `gpt-live-transcribe` ile canlı konuşma tanıma.
- Tanınan cümleyi Responses API üzerinden Türkçeye çevirip ekranda gösterme.

## Önemli sınırlama
Bu ilk prototip, tarayıcı sesini Android'in dahili ses yakalama API'siyle doğrudan almıyor; mikrofonu kullanıyor. Bu nedenle videoyu telefon hoparlöründen oynatıp sesi mikrofona duyurmak gerekir. Kulaklıkta, sessiz ortamda veya ses yakalamayı engelleyen sitelerde çalışmayabilir. Sonraki geliştirme aşamasında Android `AudioPlaybackCapture` + MediaProjection izni eklenmeli; bunun da kaynak uygulamanın yakalamaya izin vermesine bağlı olduğu unutulmamalıdır.

## Sunucuyu çalıştırma
1. Node.js 20+ kur.
2. `server` klasöründe `npm install` çalıştır.
3. `.env.example` dosyasını `.env` olarak kopyala.
4. `.env` içine kendi OpenAI API anahtarını yaz. Anahtarı Android uygulamasına koyma.
5. `npm start` çalıştır.
6. Sunucuyu HTTPS/WSS destekleyen bir sunucuya dağıt. Android uygulamasındaki WebSocket adresine `wss://.../` adresini yaz.

Yerel ağ testi için telefon ve bilgisayar aynı Wi-Fi'da olmalı; uygulamadaki adres `ws://BILGISAYARIN_LAN_IP:8787` olabilir. Gerçek kullanımda TLS/WSS kullan.

## Android Studio
- Android Studio'da bu klasörü `Open` ile aç.
- Gradle senkronizasyonunu tamamla.
- Android 10 veya üstü cihazda çalıştır.
- İlk açılışta mikrofon iznini, ardından diğer uygulamaların üzerinde gösterme iznini ver.
- Sunucu WSS adresini gir ve başlat.

## Bilinen prototip eksikleri
- Cümle sonu algılama şu an sabit aralıkla tamponu commit ediyor; bu, bazı cümleleri bölebilir. Üretim sürümünde VAD eklenecek.
- Dil otomatik algılama ve çoklu dil bağlamı henüz etkin değil; ilk test için İngilizce varsayılan.
- Sunucu kimlik doğrulaması, kullanıcı başına kota, rate limit ve maliyet kontrolü eklenmeden internete açık bırakılmamalı.
- Üretim sürümünde sunucuya istemci kimlik doğrulaması ve güvenli oturum açma eklenmelidir.
- Android 14+ foreground service / mikrofon izin akışları cihaz üreticisine göre test edilmelidir.

## Güvenlik
API anahtarı yalnızca sunucunun `.env` dosyasında tutulur. `.env` dosyasını kaynak kontrolüne veya paylaşılabilir ZIP'e ekleme.
