import 'dotenv/config';
import { WebSocketServer, WebSocket } from 'ws';

const port = Number(process.env.PORT || 8787);
const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) throw new Error('OPENAI_API_KEY is required');
const wss = new WebSocketServer({ port });

wss.on('connection', (client) => {
  const upstream = new WebSocket('wss://api.openai.com/v1/realtime?intent=transcription', {
    headers: { Authorization: `Bearer ${apiKey}` }
  });
  let ready = false;
  let commitTimer;
  let transcriptBuffer = '';
  const sendClient = (obj) => { if (client.readyState === WebSocket.OPEN) client.send(JSON.stringify(obj)); };

  upstream.on('open', () => {
    ready = true;
    upstream.send(JSON.stringify({
      type: 'session.update',
      session: {
        type: 'transcription',
        audio: { input: {
          format: { type: 'audio/pcm', rate: 24000 },
          transcription: { model: 'gpt-live-transcribe', delay: 'low' },
          turn_detection: null
        } }
      }
    }));
    sendClient({ type: 'status', text: 'Canlı dinleme başladı — altyazı bekleniyor' });
    // Prototipte kısa aralıklarla ses tamponu tamamlanır. İleri sürümde VAD ile cümle sonu algılanacak.
    commitTimer = setInterval(() => {
      if (upstream.readyState === WebSocket.OPEN) upstream.send(JSON.stringify({ type: 'input_audio_buffer.commit' }));
    }, 3200);
  });

  client.on('message', (data, isBinary) => {
    if (isBinary && ready && upstream.readyState === WebSocket.OPEN) {
      upstream.send(JSON.stringify({ type: 'input_audio_buffer.append', audio: Buffer.from(data).toString('base64') }));
    }
  });

  upstream.on('message', async (raw) => {
    let event;
    try { event = JSON.parse(raw.toString()); } catch { return; }
    if (event.type === 'conversation.item.input_audio_transcription.completed' && event.transcript?.trim()) {
      const source = event.transcript.trim();
      try {
        const r = await fetch('https://api.openai.com/v1/responses', {
          method: 'POST',
          headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: process.env.TRANSLATION_MODEL || 'gpt-5.1-mini',
            instructions: 'Translate the following spoken dialogue into natural, concise Turkish subtitles. Preserve meaning, tone, names and context. Return only the Turkish translation; no explanations.',
            input: source
          })
        });
        const data = await r.json();
        if (!r.ok) throw new Error(data.error?.message || `Translation API error ${r.status}`);
        const text = data.output?.flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('') || '';
        if (text) sendClient({ type: 'subtitle', text });
      } catch (e) { sendClient({ type: 'status', text: `Çeviri hatası: ${e.message}` }); }
    }
    if (event.type === 'error') sendClient({ type: 'status', text: event.error?.message || 'Ses tanıma hatası' });
  });

  const cleanup = () => { clearInterval(commitTimer); try { upstream.close(); } catch {} };
  client.on('close', cleanup);
  client.on('error', cleanup);
  upstream.on('close', cleanup);
  upstream.on('error', (e) => sendClient({ type: 'status', text: `Ses bağlantısı: ${e.message}` }));
});
console.log(`Video Çeviri WS server listening on :${port}`);
